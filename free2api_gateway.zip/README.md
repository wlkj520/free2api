# AI签到网关 (free2api)

一个 Android 本地网关：把已登录的 AI 网页服务 / API Key 服务，统一封装成 **OpenAI 兼容 API**。
本机或局域网内任何 OpenAI SDK 都能调用。

## 功能（全量）
- 多目标反代：内置 小浣熊/讯飞星火/灵办AI/智谱清言/Kimi/通义千问/豆包/腾讯元宝/DeepSeek/ChatGPT 预设
- 运行时增删改目标（目标管理界面）
- Cookie 登录：WebView 登录后一键保存 Cookie；支持「清Cookie再登录」换号
- 多账号管理：每目标多个账号，转发时自动轮询；也可 model 里指定 `kimi:账号2`
- 手动填 Key：Key 鉴权型目标直接输入
- OpenAI 协议适配：非 OpenAI 格式的上游自动转换（含 SSE 聚合）
- SSE 流式透传：OpenAI 兼容目标支持 stream=true
- 网关鉴权：可设置网关 Key，客户端需带 Authorization
- 端口自定义 + 局域网开放 (0.0.0.0)
- 开机自启、前台常驻、悬浮窗状态（端口+请求数）
- 请求日志（最近 200 条）

## 构建
1. Android Studio 打开本工程（或本机 gradle）
2. `gradle assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
3. 安装即可，无需特殊权限配置

## 使用
1. 目标管理 → 启用想用的目标
2. 账号与登录 → 选目标 → WebView 登录 → 保存 Cookie（或填 Key）
3. 启动网关 → 客户端指向 `http://<手机IP>:8080/v1`
   - `GET /v1/models` 列出所有启用的目标
   - `model` 字段填目标 id（如 `kimi`），或 `kimi:账号名` 指定账号

## 重要说明
- 内置目标的 API 路径是最佳已知值，**上游随时会改**。调不通时抓包
  （目标网页按 F12 或用抓包工具）确认基址与路径，在「目标管理」里直接改。
- 标了「启用协议转换」的目标走 ProtocolAdapter 启发式转换；个别特殊
  协议（如讯飞星火的 WebSocket）可能需要按抓包结果微调 ProtocolAdapter。
- 开了局域网开放后任何同网设备都能调用，务必设置网关 Key。
- 用非官方方式接入他人服务有封号风险，风险自担。
