package dev.free2api.ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import dev.free2api.service.RequestLog;

/** 请求日志 */
public class LogActivity extends Activity {
    private TextView tv;

    @Override
    public void onCreate(Bundle s) {
        super.onCreate(s);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);

        Button refresh = new Button(this);
        refresh.setText("刷新");
        refresh.setOnClickListener(v -> tv.setText(RequestLog.dump()));
        layout.addView(refresh);

        tv = new TextView(this);
        tv.setText(RequestLog.dump());
        tv.setTextIsSelectable(true);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        layout.addView(tv);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(layout);
        setContentView(scroll);
    }
}
