package dev.free2api.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import dev.free2api.service.Target;
import dev.free2api.service.TargetRegistry;
import java.util.List;

/** 目标管理：列出/编辑/启停/新增 */
public class TargetListActivity extends Activity {
    LinearLayout list;

    @Override
    public void onCreate(Bundle s) {
        super.onCreate(s);
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);

        layout.addView(label("点击目标进入编辑；括号内为启用状态"));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        layout.addView(list);

        Button add = new Button(this);
        add.setText("＋ 新增自定义目标");
        add.setOnClickListener(v -> startActivity(new Intent(this, TargetEditActivity.class)));
        layout.addView(add);

        scroll.addView(layout);
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        rebuild();
    }

    private void rebuild() {
        list.removeAllViews();
        List<Target> all = TargetRegistry.all(this);
        for (final Target t : all) {
            Button b = new Button(this);
            b.setText(t.name + "  (" + (t.enabled ? "启用" : "停用") + ")");
            b.setOnClickListener(v -> {
                Intent i = new Intent(this, TargetEditActivity.class);
                i.putExtra(TargetEditActivity.EXTRA_ID, t.id);
                startActivity(i);
            });
            list.addView(b);
        }
        if (all.isEmpty()) list.addView(label("暂无目标"));
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, 16, 0, 16);
        return t;
    }
}
