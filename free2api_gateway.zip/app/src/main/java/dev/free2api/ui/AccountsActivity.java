package dev.free2api.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import dev.free2api.service.Account;
import dev.free2api.service.AccountStore;
import dev.free2api.service.Target;
import dev.free2api.service.TargetRegistry;
import java.util.ArrayList;
import java.util.List;

/** 多账号管理：WebView 登录添加 / 手动填 Key / 启停 / 删除 */
public class AccountsActivity extends Activity {
    private Spinner targetSpin;
    private LinearLayout list;

    @Override
    public void onCreate(Bundle s) {
        super.onCreate(s);
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);

        targetSpin = new Spinner(this);
        layout.addView(targetSpin);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        layout.addView(list);

        Button login = new Button(this);
        login.setText("WebView 登录添加账号");
        login.setOnClickListener(v -> {
            Target t = selectedTarget();
            if (t == null) return;
            Intent i = new Intent(this, AuthActivity.class);
            i.putExtra(AuthActivity.EXTRA_TARGET, t.id);
            startActivity(i);
        });
        layout.addView(login);

        Button addKey = new Button(this);
        addKey.setText("手动填 Key 添加账号");
        addKey.setOnClickListener(v -> addKeyAccount());
        layout.addView(addKey);

        scroll.addView(layout);
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        rebuild();
    }

    private Target selectedTarget() {
        int pos = targetSpin.getSelectedItemPosition();
        List<Target> all = TargetRegistry.all(this);
        if (pos < 0 || pos >= all.size()) return null;
        return all.get(pos);
    }

    private void addKeyAccount() {
        Target t = selectedTarget();
        if (t == null) return;
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(this);
        b.setTitle("输入 " + t.name + " 的 Key");
        final EditText input = new EditText(this);
        b.setView(input);
        b.setPositiveButton("保存", (d, w) -> {
            String k = input.getText().toString().trim();
            if (!k.isEmpty()) {
                AccountStore.add(this, t.id, "Key账号" + (AccountStore.list(this, t.id).size() + 1), "", k);
                rebuild();
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    private void rebuild() {
        List<Target> all = TargetRegistry.all(this);
        List<String> names = new ArrayList<>();
        for (Target t : all) names.add(t.name + " (" + t.id + ")");
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names);
        targetSpin.setAdapter(ad);
        if (lastSpinPos >= 0 && lastSpinPos < all.size()) targetSpin.setSelection(lastSpinPos);
        targetSpin.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, android.view.View v, int pos, long id) {
                if (pos != lastSpinPos) { lastSpinPos = pos; showAccounts(); }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) { }
        });
        showAccounts();
    }

    private int lastSpinPos = -1;

    private void showAccounts() {
        Target t = selectedTarget();
        list.removeAllViews();
        if (t == null) return;
        List<Account> accounts = AccountStore.list(this, t.id);
        if (accounts.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("该目标还没有账号，去登录或填 Key");
            tv.setPadding(0, 16, 0, 16);
            list.addView(tv);
            return;
        }
        for (int i = 0; i < accounts.size(); i++) {
            final int idx = i;
            final Account a = accounts.get(i);
            Button b = new Button(this);
            String preview = (a.cookie != null && !a.cookie.isEmpty())
                    ? a.cookie.substring(0, Math.min(24, a.cookie.length())) + "…"
                    : (a.key == null ? "" : a.key.substring(0, Math.min(16, a.key.length())) + "…");
            b.setText(a.name + (a.enabled ? " ✓" : " ✗") + "\n" + preview);
            b.setOnClickListener(v -> toggleAccount(t, idx, a));
            b.setOnLongClickListener(v -> { deleteAccount(t, idx); return true; });
            list.addView(b);
        }
        TextView tip = new TextView(this);
        tip.setText("点按=启停 · 长按=删除");
        tip.setPadding(0, 12, 0, 12);
        list.addView(tip);
    }

    private void toggleAccount(Target t, int idx, Account a) {
        AccountStore.setEnabled(this, t.id, idx, !a.enabled);
        showAccounts();
    }

    private void deleteAccount(Target t, int idx) {
        AccountStore.remove(this, t.id, idx);
        showAccounts();
    }
}
