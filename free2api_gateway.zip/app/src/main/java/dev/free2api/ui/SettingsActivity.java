package dev.free2api.ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import dev.free2api.service.GatewayService;

/** 设置：端口 / 局域网 / 网关Key / 开机自启 */
public class SettingsActivity extends Activity {
    @Override
    public void onCreate(Bundle s) {
        super.onCreate(s);
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);

        final android.content.SharedPreferences p = getSharedPreferences(GatewayService.PREFS, 0);

        final EditText port = new EditText(this);
        port.setHint("端口 (默认 8080)");
        port.setText(String.valueOf(p.getInt("port", 8080)));
        layout.addView(port);

        final CheckBox lan = new CheckBox(this);
        lan.setText("开放局域网 (0.0.0.0，电脑也能调用)");
        lan.setChecked(p.getBoolean("lan_open", true));
        layout.addView(lan);

        final EditText key = new EditText(this);
        key.setHint("网关鉴权 Key（留空=不鉴权）");
        key.setText(p.getString("gateway_key", ""));
        layout.addView(key);

        final CheckBox boot = new CheckBox(this);
        boot.setText("开机自启网关");
        boot.setChecked(p.getBoolean("autostart", false));
        layout.addView(boot);

        Button save = new Button(this);
        save.setText("保存(重启服务后生效)");
        save.setOnClickListener(v -> {
            int pt;
            try { pt = Integer.parseInt(port.getText().toString().trim()); }
            catch (Exception e) { pt = 8080; }
            if (pt < 1 || pt > 65535) pt = 8080;
            p.edit().putInt("port", pt)
                    .putBoolean("lan_open", lan.isChecked())
                    .putString("gateway_key", key.getText().toString().trim())
                    .putBoolean("autostart", boot.isChecked())
                    .apply();
            Toast.makeText(this, "已保存，重启网关生效", Toast.LENGTH_SHORT).show();
            finish();
        });
        layout.addView(save);
        scroll.addView(layout);
        setContentView(scroll);
    }
}
