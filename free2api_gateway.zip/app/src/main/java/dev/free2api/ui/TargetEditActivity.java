package dev.free2api.ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import dev.free2api.service.Target;
import dev.free2api.service.TargetRegistry;

/** 编辑/新增目标：地址、登录页、鉴权方式、启用 */
public class TargetEditActivity extends Activity {
    public static final String EXTRA_ID = "id";
    private EditText id, name, baseUrl, apiPath, loginUrl, cookieDomain;
    private CheckBox useCookie, useKey, useAdapter, enabled;
    private String currentId = null;

    @Override
    public void onCreate(Bundle s) {
        super.onCreate(s);
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);

        id = field(layout, "目标 id（模型名，英文）");
        name = field(layout, "显示名称");
        baseUrl = field(layout, "API 基址 https://...");
        apiPath = field(layout, "chat 上游路径(留空=透传)");
        loginUrl = field(layout, "WebView 登录页");
        cookieDomain = field(layout, "Cookie 域");
        useCookie = check(layout, "Cookie 鉴权(WebView登录)");
        useKey = check(layout, "Key 鉴权(Authorization)");
        useAdapter = check(layout, "非OpenAI格式(启用协议转换)");
        enabled = check(layout, "启用该目标");
        enabled.setChecked(true);

        String editId = getIntent().getStringExtra(EXTRA_ID);
        if (editId != null) {
            Target t = TargetRegistry.findById(this, editId);
            if (t != null) {
                currentId = t.id;
                id.setText(t.id); name.setText(t.name); baseUrl.setText(t.baseUrl);
                apiPath.setText(t.apiPath); loginUrl.setText(t.loginUrl);
                cookieDomain.setText(t.cookieDomain);
                useCookie.setChecked(t.useCookie); useKey.setChecked(t.useKey);
                useAdapter.setChecked(t.useAdapter); enabled.setChecked(t.enabled);
                id.setEnabled(false);
            }
        }

        Button save = new Button(this);
        save.setText("保存");
        save.setOnClickListener(v -> save());
        layout.addView(save);

        if (editId != null) {
            Button del = new Button(this);
            del.setText("删除该目标");
            del.setOnClickListener(v -> {
                TargetRegistry.delete(this, currentId);
                Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
                finish();
            });
            layout.addView(del);
        }
        scroll.addView(layout);
        setContentView(scroll);
    }

    private void save() {
        String tid = id.getText().toString().trim();
        String bUrl = baseUrl.getText().toString().trim();
        if (tid.isEmpty() || bUrl.isEmpty()) {
            Toast.makeText(this, "id 和基址必填", Toast.LENGTH_SHORT).show();
            return;
        }
        Target t = new Target();
        t.id = tid; t.name = name.getText().toString().trim();
        if (t.name.isEmpty()) t.name = tid;
        t.baseUrl = bUrl; t.apiPath = apiPath.getText().toString().trim();
        t.loginUrl = loginUrl.getText().toString().trim();
        t.cookieDomain = cookieDomain.getText().toString().trim();
        t.useCookie = useCookie.isChecked(); t.useKey = useKey.isChecked();
        t.useAdapter = useAdapter.isChecked(); t.enabled = enabled.isChecked();
        if (currentId != null && !currentId.equals(tid)) TargetRegistry.delete(this, currentId);
        TargetRegistry.save(this, t);
        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
        finish();
    }

    private EditText field(LinearLayout l, String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(13);
        l.addView(e);
        return e;
    }

    private CheckBox check(LinearLayout l, String text) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        l.addView(c);
        return c;
    }
}
