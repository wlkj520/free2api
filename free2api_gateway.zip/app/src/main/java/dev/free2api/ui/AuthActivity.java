package dev.free2api.ui;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import dev.free2api.service.AccountStore;
import dev.free2api.service.Target;
import dev.free2api.service.TargetRegistry;

/** WebView 登录目标站点，保存 Cookie 为一个账号 */
public class AuthActivity extends Activity {
    public static final String EXTRA_TARGET = "targetId";
    private WebView webView;
    private Target target;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        target = TargetRegistry.findById(this, getIntent().getStringExtra(EXTRA_TARGET));
        if (target == null) { Toast.makeText(this, "未指定目标", Toast.LENGTH_SHORT).show(); finish(); return; }

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        TextView tip = new TextView(this);
        tip.setText("登录 " + target.name + " 后，点下方按钮保存 Cookie\n（换号登录：先点「清Cookie再登录」）");
        tip.setPadding(24, 16, 24, 16);
        layout.addView(tip);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        layout.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        Button clear = new Button(this);
        clear.setText("清Cookie再登录");
        clear.setOnClickListener(v -> {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
            webView.loadUrl(target.loginUrl);
        });
        bar.addView(clear, new LinearLayout.LayoutParams(0, -2, 1f));
        Button save = new Button(this);
        save.setText("保存Cookie并返回");
        save.setOnClickListener(v -> saveCookie());
        bar.addView(save, new LinearLayout.LayoutParams(0, -2, 1f));
        layout.addView(bar);

        setContentView(layout);
        webView.loadUrl(target.loginUrl);
    }

    private void saveCookie() {
        CookieManager.getInstance().flush();
        String cookie = CookieManager.getInstance().getCookie(target.cookieDomain);
        if (cookie == null || cookie.isEmpty()) {
            Toast.makeText(this, "该域下没有 Cookie，先完成登录", Toast.LENGTH_LONG).show();
            return;
        }
        int n = AccountStore.list(this, target.id).size();
        AccountStore.add(this, target.id, "账号" + (n + 1), cookie, "");
        Toast.makeText(this, "已保存 " + target.name + " 账号" + (n + 1), Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
