package dev.free2api.ui;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import dev.free2api.service.GatewayService;
import dev.free2api.service.Target;
import dev.free2api.service.TargetRegistry;

public class MainActivity extends Activity {
    private TextView statusText;
    private Button toggleButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 64, 48, 48);

        TextView title = new TextView(this);
        title.setText("AI签到网关");
        title.setTextSize(22);
        layout.addView(title);

        statusText = new TextView(this);
        statusText.setTextSize(14);
        statusText.setPadding(0, 24, 0, 24);
        layout.addView(statusText);

        toggleButton = new Button(this);
        toggleButton.setOnClickListener(v -> toggle());
        layout.addView(toggleButton);

        layout.addView(btn("目标管理", v -> startActivity(new Intent(this, TargetListActivity.class))));
        layout.addView(btn("账号与登录", v -> startActivity(new Intent(this, AccountsActivity.class))));
        layout.addView(btn("设置(端口/局域网/网关Key/自启)", v -> startActivity(new Intent(this, SettingsActivity.class))));
        layout.addView(btn("请求日志", v -> startActivity(new Intent(this, LogActivity.class))));
        layout.addView(btn("悬浮窗 开/关", v -> toggleFloating()));

        TextView help = new TextView(this);
        help.setText("\n用法：\n1. 「目标管理」启用要反代的服务\n2. 「账号与登录」WebView 登录或填 Key\n3. 启动网关，OpenAI SDK 指向\n    http://手机IP:端口/v1\n    model 填目标 id（如 kimi）\n    或 kimi:账号名 指定账号\n\n注意：使用他人服务的非官方接口有封号风险，风险自担。");
        help.setTextSize(12);
        layout.addView(help);

        scroll.addView(layout);
        setContentView(scroll);
    }

    private Button btn(String text, android.view.View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        return b;
    }

    private void toggle() {
        Intent i = new Intent(this, GatewayService.class);
        if (GatewayService.RUNNING) {
            stopService(i);
            Toast.makeText(this, "已停止", Toast.LENGTH_SHORT).show();
        } else {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            Toast.makeText(this, "网关已启动", Toast.LENGTH_SHORT).show();
        }
        refresh();
    }

    private void toggleFloating() {
        if (Build.VERSION.SDK_INT >= 26 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        Intent i = new Intent(this, dev.free2api.service.FloatingWindowService.class);
        if (dev.free2api.service.FloatingWindowService.SHOWN) stopService(i);
        else startService(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean running = GatewayService.RUNNING;
        int port = getSharedPreferences(GatewayService.PREFS, 0).getInt("port", 8080);
        boolean lan = getSharedPreferences(GatewayService.PREFS, 0).getBoolean("lan_open", true);
        statusText.setText(running
                ? "状态：运行中 · 端口 " + port + " · " + (lan ? "局域网开放" : "仅本机")
                : "状态：未启动");
        toggleButton.setText(running ? "停止网关服务" : "启动网关服务");
    }
}
