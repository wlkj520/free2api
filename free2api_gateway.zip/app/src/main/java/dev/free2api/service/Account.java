package dev.free2api.service;

import org.json.JSONObject;

/** 目标下的一个账号（Cookie 或 Key） */
public class Account {
    public String name;
    public String cookie;
    public String key;
    public boolean enabled = true;

    public JSONObject toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("name", name); o.put("cookie", cookie == null ? "" : cookie);
            o.put("key", key == null ? "" : key); o.put("enabled", enabled);
            return o;
        } catch (Exception e) { return new JSONObject(); }
    }

    public static Account fromJson(JSONObject o) {
        Account a = new Account();
        a.name = o.optString("name");
        a.cookie = o.optString("cookie");
        a.key = o.optString("key");
        a.enabled = o.optBoolean("enabled", true);
        return a;
    }
}
