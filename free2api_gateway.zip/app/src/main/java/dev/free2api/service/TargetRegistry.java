package dev.free2api.service;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** 目标注册表：内置签到类 AI 预设 + 运行时可增删改 */
public class TargetRegistry {
    private static final String PREFS = "gateway_targets";
    private static final String KEY = "targets";

    /** 首次运行播种内置预设。字段是最佳已知值，上游改动后可在 App 里直接改。 */
    private static List<Target> presets() {
        List<Target> l = new ArrayList<>();
        l.add(make("xiaohuanxiong", "小浣熊(签到)", "https://raccoon.xiaohuanxiong.com", "",
                "https://xiaohuanxiong.com", "xiaohuanxiong.com", true, false, false));
        l.add(make("spark", "讯飞星火(签到)", "https://xinghuo.xfyun.cn", "",
                "https://xinghuo.xfyun.cn/spark", ".xfyun.cn", true, false, true));
        l.add(make("lingban", "灵办AI(签到)", "https://lingbanai.com", "",
                "https://lingbanai.com", "lingbanai.com", true, false, true));
        l.add(make("chatglm", "智谱清言", "https://chatglm.cn", "",
                "https://chatglm.cn", "chatglm.cn", true, false, true));
        l.add(make("kimi", "Kimi网页版", "https://kimi.moonshot.cn", "/api/chat/completions",
                "https://kimi.moonshot.cn", "kimi.moonshot.cn", true, false, true));
        l.add(make("qwen", "通义千问网页", "https://tongyi.aliyun.com", "",
                "https://tongyi.aliyun.com", "aliyun.com", true, false, true));
        l.add(make("doubao", "豆包", "https://www.doubao.com", "",
                "https://www.doubao.com", "doubao.com", true, false, true));
        l.add(make("yuanbao", "腾讯元宝", "https://yuanbao.tencent.com", "",
                "https://yuanbao.tencent.com", "tencent.com", true, false, true));
        l.add(make("deepseek", "DeepSeek网页", "https://chat.deepseek.com", "",
                "https://chat.deepseek.com", "deepseek.com", true, false, true));
        l.add(make("chatgpt", "ChatGPT(OpenAI兼容)", "https://api.openai.com", "/v1/chat/completions",
                "https://platform.openai.com/api-keys", "openai.com", false, true, false));
        return l;
    }

    private static Target make(String id, String name, String baseUrl, String apiPath,
                               String loginUrl, String cookieDomain,
                               boolean cookie, boolean key, boolean adapter) {
        Target t = new Target();
        t.id = id; t.name = name; t.baseUrl = baseUrl; t.apiPath = apiPath;
        t.loginUrl = loginUrl; t.cookieDomain = cookieDomain;
        t.useCookie = cookie; t.useKey = key; t.useAdapter = adapter;
        return t;
    }

    public static synchronized List<Target> all(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, 0);
        String raw = p.getString(KEY, null);
        if (raw == null) {
            List<Target> seed = presets();
            saveAll(ctx, seed);
            return new ArrayList<>(seed);
        }
        List<Target> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) out.add(Target.fromJson(arr.getJSONObject(i)));
        } catch (Exception ignored) { }
        return out;
    }

    public static Target find(Context ctx, String id) {
        for (Target t : all(ctx)) if (t.id.equals(id) && t.enabled) return t;
        return null;
    }

    public static void save(Context ctx, Target t) {
        List<Target> list = all(ctx);
        boolean replaced = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(t.id)) { list.set(i, t); replaced = true; break; }
        }
        if (!replaced) list.add(t);
        saveAll(ctx, list);
    }

    public static void delete(Context ctx, String id) {
        List<Target> list = all(ctx);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(id)) { list.remove(i); break; }
        }
        saveAll(ctx, list);
    }

    private static void saveAll(Context ctx, List<Target> list) {
        JSONArray arr = new JSONArray();
        for (Target t : list) arr.put(t.toJson());
        ctx.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply();
    }
}
