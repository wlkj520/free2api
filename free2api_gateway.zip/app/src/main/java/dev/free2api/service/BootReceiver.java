package dev.free2api.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 开机自启（受设置里的 autostart 开关控制） */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) return;
        if (!c.getSharedPreferences(GatewayService.PREFS, 0).getBoolean("autostart", false)) return;
        if (android.os.Build.VERSION.SDK_INT >= 26)
            c.startForegroundService(new Intent(c, GatewayService.class));
        else
            c.startService(new Intent(c, GatewayService.class));
    }
}
