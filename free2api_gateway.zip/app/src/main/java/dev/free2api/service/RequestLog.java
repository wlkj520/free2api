package dev.free2api.service;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;
import java.util.Locale;

/** 请求日志（内存环形缓冲，最新 200 条） */
public class RequestLog {
    private static final Deque<String> LOGS = new ArrayDeque<>();
    private static final SimpleDateFormat FMT = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA);

    public static synchronized void log(String method, String target, int code, long ms, String err) {
        String line = FMT.format(new Date()) + " " + method + " [" + target + "] " + code
                + " " + ms + "ms" + (err == null || err.isEmpty() ? "" : " ERR:" + err);
        LOGS.addFirst(line);
        while (LOGS.size() > 200) LOGS.removeLast();
    }

    public static synchronized String dump() {
        StringBuilder sb = new StringBuilder();
        for (String s : LOGS) sb.append(s).append('\n');
        return sb.length() == 0 ? "暂无请求" : sb.toString();
    }
}
