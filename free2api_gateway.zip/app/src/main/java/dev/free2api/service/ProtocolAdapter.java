package dev.free2api.service;

import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

/**
 * 协议适配器：非 OpenAI 格式的目标 API ↔ OpenAI 格式互转。
 * 用启发式提取正文（content/text/answer/reply/message/result），
 * 支持聚合上游 SSE 流（把 data: 分片拼成完整回复）。
 */
public class ProtocolAdapter {

    /** 请求转换：OpenAI → 目标。默认透传并强制 stream=false（适配路径统一走聚合再返回）。 */
    public static JSONObject adaptRequest(JSONObject openaiReq, Target t) {
        try {
            JSONObject out = new JSONObject(openaiReq.toString());
            out.put("stream", false);
            return out;
        } catch (Exception e) {
            return openaiReq;
        }
    }

    /** 响应转换：目标(可能是SSE) → OpenAI chat.completion */
    public static byte[] convertResponse(byte[] upstream, Target t) {
        String s = new String(upstream == null ? new byte[0] : upstream, StandardCharsets.UTF_8).trim();
        if (s.isEmpty()) return openaiError("empty upstream response");
        try {
            // 已是 OpenAI 格式：choices + object
            if (s.startsWith("{")) {
                JSONObject o = new JSONObject(s);
                if (o.has("choices")) return s.getBytes(StandardCharsets.UTF_8);
            }
            // SSE 流：聚合 delta.content
            if (s.contains("data:")) {
                String content = aggregateSse(s);
                if (content != null && !content.isEmpty()) return openaiOk(content, t);
            }
            // 普通 JSON：启发式取正文
            if (s.startsWith("{")) {
                String content = extractContent(new JSONObject(s));
                if (content != null) return openaiOk(content, t);
            }
        } catch (Exception ignored) { }
        return openaiError("cannot adapt upstream response");
    }

    /** 聚合 SSE：逐行找 data: {...}，取 delta/content 拼接 */
    private static String aggregateSse(String s) {
        StringBuilder sb = new StringBuilder();
        for (String line : s.split("\n")) {
            line = line.trim();
            if (!line.startsWith("data:")) continue;
            String payload = line.substring(5).trim();
            if (payload.isEmpty() || "[DONE]".equals(payload)) continue;
            try {
                JSONObject o = new JSONObject(payload);
                String piece = extractDelta(o);
                if (piece != null) sb.append(piece);
            } catch (Exception ignored) { }
        }
        return sb.toString();
    }

    private static String extractDelta(JSONObject o) {
        try {
            JSONArray ch = o.optJSONArray("choices");
            if (ch != null && ch.length() > 0) {
                JSONObject c = ch.getJSONObject(0);
                JSONObject d = c.optJSONObject("delta");
                if (d != null && d.optString("content", null) != null) return d.optString("content");
                JSONObject m = c.optJSONObject("message");
                if (m != null) return m.optString("content", "");
            }
        } catch (Exception ignored) { }
        return extractContent(o);
    }

    /** 启发式正文提取：直接字段 → data/result 包裹 → choices 兜底 */
    private static String extractContent(JSONObject src) {
        String[] direct = {"content", "text", "answer", "reply", "message", "result"};
        for (String f : direct) {
            Object v = src.opt(f);
            if (v instanceof String && !((String) v).isEmpty()) return (String) v;
        }
        for (String wrap : new String[]{"data", "result", "payload", "response"}) {
            JSONObject inner = src.optJSONObject(wrap);
            if (inner != null) {
                String r = extractContent(inner);
                if (r != null) return r;
            }
        }
        try {
            JSONArray ch = src.optJSONArray("choices");
            if (ch != null && ch.length() > 0) {
                return ch.getJSONObject(0).optJSONObject("message").optString("content", "");
            }
        } catch (Exception ignored) { }
        return null;
    }

    private static byte[] openaiOk(String content, Target t) {
        try {
            JSONObject out = new JSONObject();
            out.put("id", "chatcmpl-" + System.currentTimeMillis());
            out.put("object", "chat.completion");
            out.put("created", System.currentTimeMillis() / 1000);
            out.put("model", t == null ? "unknown" : t.id);
            JSONObject msg = new JSONObject();
            msg.put("role", "assistant"); msg.put("content", content == null ? "" : content);
            JSONObject choice = new JSONObject();
            choice.put("index", 0); choice.put("message", msg); choice.put("finish_reason", "stop");
            JSONArray choices = new JSONArray(); choices.put(choice);
            out.put("choices", choices);
            return out.toString().getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) {
            return openaiError("adapter build failed");
        }
    }

    private static byte[] openaiError(String msg) {
        try {
            return new JSONObject().put("error", new JSONObject().put("message", msg)).toString()
                    .getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) { return "{\"error\":{\"message\":\"adapter error\"}}".getBytes(); }
    }
}
