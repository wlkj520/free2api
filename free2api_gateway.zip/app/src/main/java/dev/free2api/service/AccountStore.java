package dev.free2api.service;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/** 多账号存储：每目标一组账号，转发时轮询取用 */
public class AccountStore {
    private static final String PREFS = "gateway_accounts";
    private static final Map<String, AtomicInteger> RR = new HashMap<>();

    public static List<Account> list(Context ctx, String targetId) {
        List<Account> out = new ArrayList<>();
        String raw = prefs(ctx).getString("accounts_" + targetId, null);
        if (raw == null) return out;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) out.add(Account.fromJson(arr.getJSONObject(i)));
        } catch (Exception ignored) { }
        return out;
    }

    public static void add(Context ctx, String targetId, String name, String cookie, String key) {
        List<Account> list = list(ctx, targetId);
        Account a = new Account();
        a.name = (name == null || name.isEmpty()) ? "账号" + (list.size() + 1) : name;
        a.cookie = cookie == null ? "" : cookie;
        a.key = key == null ? "" : key;
        list.add(a);
        save(ctx, targetId, list);
    }

    public static void remove(Context ctx, String targetId, int index) {
        List<Account> list = list(ctx, targetId);
        if (index >= 0 && index < list.size()) { list.remove(index); save(ctx, targetId, list); }
    }

    public static void setEnabled(Context ctx, String targetId, int index, boolean enabled) {
        List<Account> list = list(ctx, targetId);
        if (index >= 0 && index < list.size()) {
            list.get(index).enabled = enabled;
            save(ctx, targetId, list);
        }
    }

    /** 选账号：指定 name 优先；否则在启用账号间轮询 */
    public static Account pick(Context ctx, String targetId, String preferredName) {
        List<Account> all = list(ctx, targetId);
        if (preferredName != null && !preferredName.isEmpty()) {
            for (Account a : all) if (a.name.equals(preferredName)) return a;
        }
        List<Account> enabled = new ArrayList<>();
        for (Account a : all) if (a.enabled) enabled.add(a);
        if (enabled.isEmpty()) return null;
        AtomicInteger rr = RR.get(targetId);
        if (rr == null) { rr = new AtomicInteger(0); RR.put(targetId, rr); }
        return enabled.get(Math.abs(rr.getAndIncrement()) % enabled.size());
    }

    private static void save(Context ctx, String targetId, List<Account> list) {
        JSONArray arr = new JSONArray();
        for (Account a : list) arr.put(a.toJson());
        prefs(ctx).edit().putString("accounts_" + targetId, arr.toString()).apply();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, 0);
    }
}
