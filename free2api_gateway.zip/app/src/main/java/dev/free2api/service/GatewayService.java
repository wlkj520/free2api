package dev.free2api.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.util.Log;
import com.koushikdutta.async.AsyncServer;
import com.koushikdutta.async.ByteBufferList;
import com.koushikdutta.async.http.body.AsyncHttpRequestBody;
import com.koushikdutta.async.http.server.AsyncHttpServer;
import com.koushikdutta.async.http.server.AsyncHttpServerRequest;
import com.koushikdutta.async.http.server.AsyncHttpServerResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 核心网关：OpenAI 兼容入口 → 按模型名路由到目标 AI → 带账号 Cookie/Key 转发。
 * 支持 SSE 流式透传、协议适配、多账号轮询、网关鉴权、统计日志。
 */
public class GatewayService extends Service {
    public static final String PREFS = "gateway_prefs";
    public static volatile boolean RUNNING = false;
    public static volatile int REQ_COUNT = 0;

    private AsyncServer server;
    private AsyncHttpServer httpServer;
    private int port = 8080;
    private boolean lanOpen = true;
    private String gatewayKey = "";
    private final ExecutorService executor = Executors.newFixedThreadPool(12);

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        loadSettings();
        startForegroundNotification();
        startHttpServer();
        RUNNING = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override
    public void onDestroy() {
        RUNNING = false;
        if (httpServer != null) httpServer.stop();
        if (server != null) server.stop();
        super.onDestroy();
    }

    private void loadSettings() {
        SharedPreferences p = getSharedPreferences(PREFS, 0);
        port = p.getInt("port", 8080);
        lanOpen = p.getBoolean("lan_open", true);
        gatewayKey = p.getString("gateway_key", "");
    }

    private void startForegroundNotification() {
        NotificationChannel channel = new NotificationChannel("gateway_channel", "网关服务",
                NotificationManager.IMPORTANCE_LOW);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(channel);
        Notification n = new Notification.Builder(this, "gateway_channel")
                .setContentTitle("AI签到网关")
                .setContentText("运行中 · 端口 " + port)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setOngoing(true)
                .build();
        startForeground(1, n);
    }

    private void startHttpServer() {
        if (httpServer != null) httpServer.stop();
        server = new AsyncServer();
        httpServer = new AsyncHttpServer();

        httpServer.addAction("GET", "/v1/models", this::handleModels);
        httpServer.addAction("POST", "/v1/chat/completions", this::handleChat);
        httpServer.addAction("POST", "/v1/completions", this::handleChat);
        httpServer.addAction("GET", "/gateway/status", this::handleStatus);

        AsyncHttpServer.HttpServerRequestCallback passthrough = (req, res) -> {
            if (checkAuth(req, res)) return;
            if ("OPTIONS".equalsIgnoreCase(req.getMethod())) { res.code(200); res.send(""); return; }
            forwardPassthrough(req, res);
        };
        for (String m : new String[]{"GET", "POST", "PUT", "DELETE", "PATCH"})
            httpServer.addAction(m, ".*", passthrough);

        // lanOpen=false 时只监听本机回环，true 时监听所有网卡
        if (lanOpen) {
            httpServer.listen(server, port);
        } else {
            httpServer.listen(server, java.net.InetAddress.getByName("127.0.0.1"), port);
        }
    }

    private boolean checkAuth(AsyncHttpServerRequest req, AsyncHttpServerResponse res) {
        setCors(res);
        if (gatewayKey == null || gatewayKey.isEmpty()) return false;
        String auth = req.getHeaders().get("Authorization");
        if (auth != null && auth.replaceFirst("(?i)^Bearer\\s+", "").trim().equals(gatewayKey)) return false;
        res.code(401);
        res.send("{\"error\":{\"message\":\"invalid gateway key\"}}");
        return true;
    }

    private void setCors(AsyncHttpServerResponse res) {
        res.getHeaders().set("Access-Control-Allow-Origin", "*");
        res.getHeaders().set("Access-Control-Allow-Headers", "*");
    }

    private void handleStatus(AsyncHttpServerRequest req, AsyncHttpServerResponse res) {
        if (checkAuth(req, res)) return;
        JSONObject o = new JSONObject();
        try {
            o.put("running", RUNNING).put("port", port).put("requests", REQ_COUNT);
        } catch (Exception ignored) { }
        res.code(200); res.send(o.toString());
    }

    private void handleModels(AsyncHttpServerRequest req, AsyncHttpServerResponse res) {
        if (checkAuth(req, res)) return;
        JSONArray data = new JSONArray();
        for (Target t : TargetRegistry.all(this)) {
            if (!t.enabled) continue;
            try {
                JSONObject m = new JSONObject();
                m.put("id", t.id); m.put("object", "model"); m.put("owned_by", "free2api");
                data.put(m);
            } catch (Exception ignored) { }
        }
        res.code(200); res.send("{\"object\":\"list\",\"data\":" + data + "}");
    }

    private void handleChat(AsyncHttpServerRequest request, AsyncHttpServerResponse response) {
        if (checkAuth(request, response)) return;
        final String body = readBodyString(request);
        final String reqPath = request.getPath();
        executor.execute(() -> {
            long t0 = System.currentTimeMillis();
            int code = 200;
            String targetId = "-";
            try {
                REQ_COUNT++;
                JSONObject req = new JSONObject(body);
                String model = req.optString("model", "");
                String accountName = "";
                if (model.contains(":")) {
                    String[] parts = model.split(":", 2);
                    model = parts[0]; accountName = parts[1];
                }
                if (model.isEmpty()) model = TargetRegistry.all(this).get(0).id;
                Target target = TargetRegistry.find(this, model);
                if (target == null) throw new IllegalArgumentException("未知目标: " + model);
                targetId = target.id;
                Account acc = AccountStore.pick(this, target.id, accountName);
                if (acc == null) throw new IllegalStateException("目标 [" + target.id + "] 无可用账号，请先登录");

                boolean wantStream = req.optBoolean("stream", false);
                boolean streamToClient = wantStream && !target.useAdapter;
                if (target.useAdapter) {
                    req.put("stream", false);
                    req = ProtocolAdapter.adaptRequest(req, target);
                }

                String path = (target.apiPath == null || target.apiPath.isEmpty()) ? reqPath : target.apiPath;
                HttpURLConnection conn = open(target.baseUrl + path, "POST");
                applyAuth(conn, target, acc);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept-Encoding", "identity");
                conn.setDoOutput(true);
                conn.getOutputStream().write(req.toString().getBytes(StandardCharsets.UTF_8));

                if (streamToClient) {
                    code = conn.getResponseCode();
                    if (code >= 400) {
                        sendUpstreamError(response, conn, code);
                    } else {
                        response.getHeaders().set("Content-Type", "text/event-stream; charset=utf-8");
                        response.getHeaders().set("Cache-Control", "no-cache");
                        response.code(200);
                        BufferedReader br = new BufferedReader(
                                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                        String line;
                        while ((line = br.readLine()) != null) {
                            ByteBufferList chunk = new ByteBufferList();
                            chunk.add(java.nio.ByteBuffer.wrap((line + "\n").getBytes(StandardCharsets.UTF_8)));
                            response.write(chunk);
                        }
                        br.close();
                        response.end();
                    }
                    conn.disconnect();
                } else {
                    code = conn.getResponseCode();
                    InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
                    byte[] resp = readAll(is);
                    if (code < 400 && target.useAdapter) resp = ProtocolAdapter.convertResponse(resp, target);
                    response.code(code);
                    response.getHeaders().set("Content-Type", "application/json");
                    response.send(resp);
                    conn.disconnect();
                }
                RequestLog.log("POST", targetId, code, System.currentTimeMillis() - t0, null);
            } catch (Exception e) {
                Log.e("Gateway", "chat error", e);
                RequestLog.log("POST", targetId, 500, System.currentTimeMillis() - t0, e.getMessage());
                response.code(500);
                response.getHeaders().set("Content-Type", "application/json");
                response.send("{\"error\":{\"message\":\"" + e.getMessage() + "\"}}");
            }
        });
    }

    /** 非 /v1 路径：原样透传到当前活跃目标，路径、方法、请求体不变 */
    private void forwardPassthrough(AsyncHttpServerRequest request, AsyncHttpServerResponse response) {
        executor.execute(() -> {
            long t0 = System.currentTimeMillis();
            int code = 502;
            String targetId = "-";
            try {
                REQ_COUNT++;
                Target target = TargetRegistry.all(this).isEmpty() ? null
                        : TargetRegistry.find(this, TargetRegistry.all(this).get(0).id);
                if (target == null) throw new IllegalStateException("没有启用的目标");
                targetId = target.id;
                Account acc = AccountStore.pick(this, target.id, "");
                String url = target.baseUrl + request.getPath()
                        + (request.getQuery() != null ? "?" + request.getQuery() : "");
                HttpURLConnection conn = open(url, request.getMethod());
                applyAuth(conn, target, acc);
                for (String h : request.getHeaders().keySet()) {
                    if (!h.equalsIgnoreCase("Host") && !h.equalsIgnoreCase("Authorization")
                            && !h.equalsIgnoreCase("Cookie")) {
                        conn.setRequestProperty(h, request.getHeaders().get(h));
                    }
                }
                conn.setRequestProperty("Accept-Encoding", "identity");
                byte[] body = readReqBody(request);
                if (body.length > 0) {
                    conn.setDoOutput(true);
                    conn.getOutputStream().write(body);
                }
                code = conn.getResponseCode();
                InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
                byte[] resp = readAll(is);
                response.code(code);
                String ct = conn.getHeaderField("Content-Type");
                if (ct != null) response.getHeaders().set("Content-Type", ct);
                response.send(resp);
                conn.disconnect();
                RequestLog.log(request.getMethod(), targetId, code, System.currentTimeMillis() - t0, null);
            } catch (Exception e) {
                RequestLog.log(request.getMethod(), targetId, code, System.currentTimeMillis() - t0, e.getMessage());
                response.code(500);
                response.send("{\"error\":{\"message\":\"" + e.getMessage() + "\"}}");
            }
        });
    }

    private HttpURLConnection open(String url, String method) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(120000);
        return conn;
    }

    private void applyAuth(HttpURLConnection conn, Target t, Account a) {
        if (t.useKey && a.key != null && !a.key.isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + a.key);
        }
        if (t.useCookie) {
            if (a.cookie != null && !a.cookie.isEmpty()) {
                conn.setRequestProperty("Cookie", a.cookie);
            } else {
                String c = android.webkit.CookieManager.getInstance().getCookie(t.cookieDomain);
                if (c != null) conn.setRequestProperty("Cookie", c);
            }
        }
    }

    private void sendUpstreamError(AsyncHttpServerResponse response, HttpURLConnection conn, int code) {
        try {
            byte[] err = readAll(conn.getErrorStream());
            response.code(code);
            response.getHeaders().set("Content-Type", "application/json");
            response.send(err);
        } catch (Exception e) {
            response.code(500); response.send("{\"error\":{\"message\":\"upstream error\"}}");
        }
    }

    private String readBodyString(AsyncHttpServerRequest request) {
        byte[] b = readReqBody(request);
        return new String(b, StandardCharsets.UTF_8);
    }

    @SuppressWarnings("unchecked")
    private byte[] readReqBody(AsyncHttpServerRequest request) {
        try {
            AsyncHttpRequestBody body = request.getBody();
            if (body == null) return new byte[0];
            Object v = body.get();
            if (v instanceof JSONObject) return v.toString().getBytes(StandardCharsets.UTF_8);
            if (v instanceof JSONArray) return v.toString().getBytes(StandardCharsets.UTF_8);
            if (v instanceof String) return ((String) v).getBytes(StandardCharsets.UTF_8);
            if (v instanceof byte[]) return (byte[]) v;
            if (v instanceof ByteBufferList) return ((ByteBufferList) v).readAllBytes();
            return v.toString().getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) {
            return new byte[0];
        }
    }

    private byte[] readAll(InputStream is) throws Exception {
        if (is == null) return new byte[0];
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) != -1) baos.write(buf, 0, n);
        is.close();
        return baos.toByteArray();
    }
}
