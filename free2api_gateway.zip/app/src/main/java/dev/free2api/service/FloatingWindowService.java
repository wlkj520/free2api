package dev.free2api.service;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

/** 悬浮窗：显示端口与请求数，点按打开主界面 */
public class FloatingWindowService extends Service {
    public static volatile boolean SHOWN = false;
    private WindowManager wm;
    private TextView view;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (view != null) {
                view.setText("AI网关 :" + getPort() + " · " + GatewayService.REQ_COUNT + " 次");
                handler.postDelayed(this, 2000);
            }
        }
    };

    private int getPort() {
        return getSharedPreferences(GatewayService.PREFS, 0).getInt("port", 8080);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        SHOWN = true;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        view = new TextView(this);
        view.setText("AI网关运行中");
        view.setPadding(20, 14, 20, 14);
        view.setBackgroundColor(0xCC222222); view.setTextColor(0xFFFFFFFF);
        view.setOnClickListener(v -> {
            Intent i = new Intent(this, dev.free2api.ui.MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        });
        int type = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(-2, -2, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        wm.addView(view, p);
        handler.post(tick);
    }

    @Override
    public void onDestroy() {
        SHOWN = false;
        handler.removeCallbacks(tick);
        if (view != null && view.isAttachedToWindow()) wm.removeView(view);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
