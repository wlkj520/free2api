package dev.free2api.service;

import org.json.JSONObject;

/** 一个可反代的目标 AI 服务 */
public class Target {
    public String id;          // 模型名，如 "kimi"
    public String name;        // 显示名，如 "Kimi"
    public String baseUrl;     // 上游 API 基址
    public String apiPath;     // chat/completions 的上游路径；空=原样透传请求路径
    public String loginUrl;    // WebView 登录页
    public String cookieDomain;// Cookie 所属域
    public boolean useCookie = true;   // 带 Cookie 鉴权
    public boolean useKey = false;     // 带 Authorization: Bearer key
    public boolean useAdapter = false; // 非OpenAI格式，需协议转换
    public boolean enabled = true;

    public JSONObject toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("name", name);
            o.put("baseUrl", baseUrl); o.put("apiPath", apiPath);
            o.put("loginUrl", loginUrl); o.put("cookieDomain", cookieDomain);
            o.put("useCookie", useCookie); o.put("useKey", useKey);
            o.put("useAdapter", useAdapter); o.put("enabled", enabled);
            return o;
        } catch (Exception e) { return new JSONObject(); }
    }

    public static Target fromJson(JSONObject o) {
        Target t = new Target();
        t.id = o.optString("id"); t.name = o.optString("name", t.id);
        t.baseUrl = o.optString("baseUrl"); t.apiPath = o.optString("apiPath");
        t.loginUrl = o.optString("loginUrl"); t.cookieDomain = o.optString("cookieDomain");
        t.useCookie = o.optBoolean("useCookie", true);
        t.useKey = o.optBoolean("useKey", false);
        t.useAdapter = o.optBoolean("useAdapter", false);
        t.enabled = o.optBoolean("enabled", true);
        return t;
    }
}
